#include<iostream>
#include<cstdio>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<string>
#include<queue>
#include<vector>
#include<map>
#include<set>
#include<utility>
#include<iomanip>
using namespace std;
int randomInt(int leftBound,int rightBound){
    return leftBound+int((rightBound-leftBound)*(0.999999*rand()/RAND_MAX));
}

const int MAXN=256; // ���г���


/*
 * borda count ���оۺ�
 * @param perm: m������Ϊn������
 * @param weight: n��λ�õ�Ȩ��
 * @return �ۺϺ������
 */
vector<int> borda(vector<vector<int> >&perm, vector<int>&weight) {
    vector<pair<int,int> >val;
    int m=perm.size();
    int n=perm[0].size();
    for(int i=0;i<n;i++)
        val.push_back(make_pair(0,i+1));

    for(int i=0;i<m;i++)
        for(int j=0;j<n;j++)
            val[perm[i][j]].first+=weight[j];
    sort(val.begin(),val.end());

    vector<int>ret;
    for(int i=n-1;i>=0;i--)
        ret.push_back(val[i].second);
    return ret;
}
/*
 * �鲢����������Ը���
 * @param v: ����������
 * @param L: ����������˵�
 * @param R: ���������Ҷ˵�
 * @return ����Ը���
 */
int tmp[MAXN];
int rev_order_pair(vector<int>&v,int L,int R){
    if(L>=R)
        return 0;
    int mid=(L+R)/2;
    int ret=rev_order_pair(v,L,mid)+rev_order_pair(v,mid+1,R);
    int i=L,j=mid+1,k=L;
    while(i<=mid&&j<=R){
        if(v[i]<v[j]){
            tmp[k++]=v[i++];
        }
        else{
            tmp[k++]=v[j++];
            ret+=(mid-i+1);
        }
    }
    while(i<=mid){
        tmp[k++]=v[i++];
    }
    while(j<=R){
        tmp[k++]=j++;
        ret+=(mid-i+1);
    }
    for(int i=L;i<=R;i++)
        v[i]=tmp[i];
    return ret;
}
/*
 * ���������е�tau����
 * @param perm1: ����1
 * @param perm2: ����2
 * @return tau����
 */
double tau(vector<int>&perm1, vector<int>&perm2){
    int n=perm1.size();
    vector<pair<int,int> >p;
    pair<int,int> tmp;
    for(int i=0;i<n;i++){
        tmp=make_pair(perm1[i],perm2[i]);
        p.push_back(tmp);
    }
    sort(p.begin(),p.end());
    vector<int>perm;
    for(int i=0;i<n;i++)
        perm.push_back(p[i].second);
    return rev_order_pair(perm,0,n-1);
}


vector<int> ELAHC(vector<vector<int> >&perm, vector<int>weight, bool beginWithBorda, int Lh, double timeCutoff, double timeSpan){
	double prevUpdTime=clock(), startTime=clock(), printTime=0;
    int m=perm.size();
    int n=perm[0].size();
    vector<int>cur;
    if(!beginWithBorda){
        for(int i=0;i<n;i++)
            cur.push_back(i+1);
        random_shuffle(cur.begin(),cur.end());
    }
    else
        cur=borda(perm, weight);
    vector<int>nxt=cur;
    vector<int>best=cur;
    double curCost=0, bestCost, prevCost;
    for(int i=0;i<m;i++)
        curCost+=tau(cur,perm[i]);
	curCost/=m;
	//printf("initial: %.4f\n",curCost);
	bestCost=curCost;
    vector<double>f(Lh, curCost);
	int N=Lh;
	double maxF=curCost;
    for(long long i=0;(clock()-prevUpdTime)/CLOCKS_PER_SEC<=timeCutoff;i++){
        if((clock()-startTime)/CLOCKS_PER_SEC>=printTime){
            printf("%.4f ",bestCost);
            printTime+=timeSpan;
        }
		prevCost=curCost;
        int id1=randomInt(0,n),id2=randomInt(0,n);
        while(id1==id2)
            id2=randomInt(0,n);
        swap(nxt[id1], nxt[id2]);
        double nxtCost=0;
        for(int j=0;j<m;j++)
            nxtCost+=tau(nxt,perm[j]);
		nxtCost/=m;
        if(fabs(nxtCost-curCost)<1e-7||nxtCost<maxF){
			swap(cur[id1],cur[id2]);
			curCost=nxtCost;
			if(curCost<bestCost){
				best=cur;
				bestCost=curCost;
				prevUpdTime=clock();
			}
		}
		else
			swap(nxt[id1],nxt[id2]);
		int v=i%Lh;
		if(curCost>f[v])
			f[v]=curCost;
		else if(curCost<f[v]&&curCost<prevCost){
			if(fabs(f[v]-maxF)<1e-7)
				N--;
			f[v]=curCost;
			if(!N){
				maxF=-1;
				for(int j=0;j<Lh;j++){
					if(maxF<f[j])
						maxF=f[j],N=1;
					else if(fabs(maxF-f[j])<1e-7)
						N++;
				}
			}
		}
    }
    printf("\n");
    return best;
}

double test_ELAHC(char* INPUT,int Lh, double timeCutoff) {
    double curCost;
    freopen(INPUT,"r",stdin);
    int m,n;float f;
    scanf("%d%d%f",&n,&m,&f);
    vector<vector<int> >v;
    for(int i=0;i<m;i++){
        vector<int>v_tmp;
        v.push_back(v_tmp);
        for(int j=0;j<n;j++){
            int tmp;
            scanf("%d",&tmp);
            v[i].push_back(tmp);
        }
    }
    vector<int>w;
    for(int i=0;i<n;i++)
        w.push_back(n-i);
    vector<int>cur;
	cur=ELAHC(v, w, false, Lh, timeCutoff, 1);
	curCost=0;
	for(int i=0;i<m;i++)
		curCost+=tau(cur,v[i]);
	curCost/=m;
    return curCost;
}
void test_all_data(char* OUTPUT, int repeat_times=5){
	//freopen(OUTPUT,"w",stdout);
    char* DIR[]={"MM050n0.001", "MM050n0.01", "MM050n0.1", "MM150n0.1", "MM250n0.1"};
    char INPUT[128];
    const int LhList[10]={1, 5, 10, 15};
    int LhLength=4;
    for(int i=1;i<2;i++){
        printf("%s:\n",DIR[i]);
        for(int j=1;j<=1;j++){
            if(j<=9)
                sprintf(INPUT,"%s/dataset0%d.txt",DIR[i],j);
            else
                sprintf(INPUT,"%s/dataset%d.txt",DIR[i],j);
            printf("%s:\n",INPUT);
            for(int Lh=0;Lh<LhLength;Lh++){
                printf("Lh=%d:\n", LhList[Lh]);
                double avg=0, best=1e9;
                for(int k=0;k<repeat_times;k++){
                    double res=test_ELAHC(INPUT, LhList[Lh], 3);
                    avg+=res;
                    if(res<best)
                        best=res;
                }
                avg/=repeat_times;
                printf("avg: %.4f, best: %.4f\n",avg, best);
            }
        }
    }
}
int main(){
    srand(time(NULL));
    test_all_data("out.txt");
    return 0;
}
