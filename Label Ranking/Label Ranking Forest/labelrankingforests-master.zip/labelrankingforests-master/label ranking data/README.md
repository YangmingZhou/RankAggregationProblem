# Label ranking datasets
The original datasets can be found at: https://www-old.cs.uni-paderborn.de/fachgebiete/intelligente-systeme/software/label-ranking-datasets.html

