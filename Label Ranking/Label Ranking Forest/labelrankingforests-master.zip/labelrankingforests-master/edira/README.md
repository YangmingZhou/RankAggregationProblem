# Entropy-based Discretization for Ranking data (EDiRa)
Supervised discretization for Label Ranking datasets

Please include this citation if you use this code:

de Sa, C. R., Soares, C. & Knobbe, A. J. (2016), `Entropy-based discretization methods for ranking data', Information Sciences 329, 921-936
